import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { App1Component } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
// import { ListComponent } from './users/list/list.component';
// import { AddComponent } from './users/add/add.component';

import { AppRoutingModule } from './app-routing.module';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

import { UsersModule } from './users/users.module';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { acceptOnlyGmailValidatorDirective } from './shared/accept-only-gmail.validator';
import { UserService } from './users/user.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    App1Component,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    PageNotFoundComponent,
    LoginComponent,
    RegisterComponent,
    acceptOnlyGmailValidatorDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    UsersModule,
    HttpClientModule
  ],
  providers: [
    UserService
  ],
  bootstrap: [App1Component]
})
export class AppModule { }
