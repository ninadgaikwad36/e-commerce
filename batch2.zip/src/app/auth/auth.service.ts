import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  baseUrl = "http://localhost:3000/";
  private userData = {};
  constructor(private http:HttpClient) { }


  login(data:any) {
    return this.http.get(this.baseUrl+'users?email='+data.email+'&password='+data.password);
  }

  setUserData(userData:any) {
    this.userData = userData;
  }

  getUserData() {
    return this.userData;
  }

}
