import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from './list/list.component';
import { AddComponent } from './add/add.component';
import { AuthGuard } from '../auth/auth.guard';
import { ListGuard } from './list.guard';

const routes: Routes = [
  {
      path: 'users/list',
      component: ListComponent,
      canActivate:[AuthGuard],
      resolve:{'users':ListGuard}
  },
  {
      path: 'users/add',
      component: AddComponent,
      canActivate:[AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
