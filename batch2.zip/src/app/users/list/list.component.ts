import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  usersList:any = [];
  constructor(private userService:UserService,private aR:ActivatedRoute) { }

  ngOnInit(): void {
    this.usersList = this.aR.snapshot.data['users'];    
  }

  delete(id:number) {
    Swal.fire({
      title: 'Delete',
      text: 'Are u sure u want to delete this record',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ok',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      console.log(result);
      if(result.isConfirmed) {
        this.userService.deleteUser(id).subscribe((result) => {
          this.getusers();
        });
      }
    });

    
  }

  getusers() {
    this.userService.getList().subscribe((list) => {
      this.usersList = list;
    });
  }

}
